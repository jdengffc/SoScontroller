#!/bin/sh

#----------------------------------------------------------------------
# Author: Juan Deng
#
# Scripts for installing and running floodlight-0.9.
#----------------------------------------------------------------------
_user="$(id -u -n)"


sudo apt-get update
sudo apt-get install ant -y
sudo apt-get install git -y

cd /users/$_user
git clone https://jdengffc@bitbucket.org/jdengffc/steroidopenflowservice.git
cd /users/$_user/steroidopenflowservice
sudo tar -xzf jdk-8u11-linux-x64.tar.gz -C /usr/lib/jvm
export JAVA_HOME=/usr/lib/jvm/jdk1.8.0_11		

cd /users/$_user/steroidopenflowservice	
tar -xzf floodlight-source-0.90.tar.gz
cd /users/$_user/steroidopenflowservice/floodlight-0.90
ant
/usr/lib/jvm/jdk1.8.0_11/bin/java -jar /users/$_user/steroidopenflowservice/floodlight-0.90/target/floodlight.jar &

