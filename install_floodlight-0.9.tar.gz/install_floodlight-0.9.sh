#!/bin/sh

#----------------------------------------------------------------------
# Author: Juan Deng
#
# Scripts for installing and running floodlight-0.9.
#----------------------------------------------------------------------
_user="$(id -u -n)"

cd /users/$_user



	sudo apt-get update
	sudo apt-get install ant -y

	wget https://bytebucket.org/jdengffc/steroidopenflowservice/raw/1d9cb0022bdcee961025509ba51a466772b19e27/jdk-8u11-linux-x64.tar.gz
	sudo tar -xzf jdk-8u11-linux-x64.tar.gz -C /usr/lib/jvm
	#sudo mv /usr/lib/jvm/java-6-openjdk-amd64 /usr/lib/jvm/java-6-openjdk-amd64.old
	#sudo ln -s /usr/lib/jvm/jdk1.8.0_11 /usr/lib/jvm/java-6-openjdk-amd64
	export JAVA_HOME=/usr/lib/jvm/jdk1.8.0_11		

	wget https://bytebucket.org/jdengffc/steroidopenflowservice/raw/1d9cb0022bdcee961025509ba51a466772b19e27/floodlight-source-0.90.tar.gz
	tar -xzf floodlight-source-0.90.tar.gz
	cd /users/$_user/floodlight-0.90
	ant
	/usr/lib/jvm/jdk1.8.0_11/bin/java -jar /users/$_user/floodlight-0.90/target/floodlight.jar &

