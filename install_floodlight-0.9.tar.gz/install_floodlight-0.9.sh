#!/bin/sh

#----------------------------------------------------------------------
# Author: Juan Deng
#
# Scripts for installing and running floodlight-0.9.
#----------------------------------------------------------------------

sudo apt-get update
sudo apt-get install ant -y

wget https://bytebucket.org/jdengffc/steroidopenflowservice/raw/1d9cb0022bdcee961025509ba51a466772b19e27/jdk-8u11-linux-x64.tar.gz
sudo tar -xzf jdk-8u11-linux-x64.tar.gz -C /usr/lib/jvm
export JAVA_HOME=/usr/lib/jvm/jdk1.8.0_11

wget https://bytebucket.org/jdengffc/steroidopenflowservice/raw/1d9cb0022bdcee961025509ba51a466772b19e27/floodlight-source-0.90.tar.gz
sudo tar -xzf floodlight-source-0.90.tar.gz
cd floodlight-0.90/
ant
java -jar target/floodlight.jar &
